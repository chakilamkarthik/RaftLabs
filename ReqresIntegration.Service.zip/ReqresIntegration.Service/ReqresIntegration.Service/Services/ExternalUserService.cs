﻿using ReqresIntegration.Service.Models;
using ReqresIntegration.Service.Services;
using System.Net.Http;
using System.Text.Json;

public class ExternalUserService : IExternalUserService
{
    private readonly HttpClient _httpClient;

    public ExternalUserService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<User> GetUserByIdAsync(int userId)
    {
        var Response = await _httpClient.GetAsync($"users/{userId}");

        if (Response.IsSuccessStatusCode)
        {
            var stream = await Response.Content.ReadAsStreamAsync();
            var wrapper = await JsonSerializer.DeserializeAsync<UserWrapper>(stream,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            return wrapper?.Data ?? throw new Exception("User not found in response.");
        }

        throw new Exception($"Failed to fetch user: {Response.StatusCode}");
    }

    public async Task<IEnumerable<User>> GetAllUsersAsync()
    {
        List<User> AllUsers = new List<User>();
        int Page = 1;
        bool MorePages = true;

        while (MorePages)
        {   
            //Calling Users service by sending the Page
            var Response = await _httpClient.GetAsync($"users?page={Page}");

            if (!Response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to fetch page {Page}: {Response.StatusCode}");
            }

            var content = await Response.Content.ReadAsStringAsync();

            var PageData = JsonSerializer.Deserialize<UserPage>(content);

            if (PageData == null || PageData.Data == null)
            {
                throw new Exception($"Invalid response on page {Page}");
            }

            AllUsers.AddRange(PageData.Data);

            if (Page >= PageData.Total_Pages)
                MorePages = false;
            else
                Page++;
        }

        return AllUsers;
    }

}
