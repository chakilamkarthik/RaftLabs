﻿namespace ReqresIntegration.Service
{
    public class Class1
    {

    }
}
