﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ReqresIntegration.Service.Services;
using System;
using System.IO;
using System.Threading.Tasks;
using Polly;
using Polly.Extensions.Http;

class Program
{
    static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder()
            .ConfigureAppConfiguration((context, config) =>
            {
                config.SetBasePath(Directory.GetCurrentDirectory())
                      .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            })
            .ConfigureServices((context, services) =>
            {
                var baseUrl = context.Configuration["ReqresApi:BaseUrl"];
                services.AddHttpClient<IExternalUserService, ExternalUserService>(client =>
                {
                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders.Add("x-api-key", "reqres-free-v1");
                });
            })
            .Build();

        try
        {
            var userService = host.Services.GetRequiredService<IExternalUserService>();

            Console.WriteLine("\nFetching user with ID 2...\n");
            //Calling the GetUserById service by passing the parameter value as 2
            var userById = await userService.GetUserByIdAsync(2);
            Console.WriteLine($"\n{userById.Id} - {userById.First_Name} {userById.Last_Name} ({userById.Email}) ({userById.Avatar})");


            Console.WriteLine("Fetching all users...\n");
            //Calling the GetAllUsersAsync service
            var users = await userService.GetAllUsersAsync();
            foreach (var user in users)
            {
                Console.WriteLine($"{user.Id} - {user.First_Name} {user.Last_Name} ({user.Email})  ({user.Avatar})");
            }

           
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: " + ex.Message);
        }

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}
