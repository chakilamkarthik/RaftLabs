﻿using Moq;
using Moq.Protected;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using ReqresIntegration.Service;
using System.Collections.Generic;
using System.Text.Json;
using ReqresIntegration.Service.Models;


namespace ReqresIntegration.Tests
{
    
    public class ExternalUserServiceTests
    {
        [Fact]
        public async Task GetUserByIdAsync_ReturnsCorrectUser()
        {
            // Arrange
            var userId = 2;
            var expectedUser = new User
            {
                Id = 2,
                Email = "janet.weaver@reqres.in",
                First_Name = "Janet",
                Last_Name = "Weaver"
            };

            var responseContent = JsonSerializer.Serialize(new
            {
                data = expectedUser
            });

            var handlerMock = new Mock<HttpMessageHandler>();

            handlerMock
               .Protected()
               .Setup<Task<HttpResponseMessage>>(
                  "SendAsync",
                  ItExpr.Is<HttpRequestMessage>(req =>
                     req.Method == HttpMethod.Get &&
                     req.RequestUri.ToString().EndsWith($"/users/{userId}")
                  ),
                  ItExpr.IsAny<CancellationToken>()
               )
               .ReturnsAsync(new HttpResponseMessage
               {
                   StatusCode = HttpStatusCode.OK,
                   Content = new StringContent(responseContent),
               });

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("https://reqres.in/api/")
            };

            var service = new ExternalUserService(httpClient);

            // Act
            var result = await service.GetUserByIdAsync(userId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedUser.Email, result.Email);
            Assert.Equal(expectedUser.First_Name, result.First_Name);
        }
    }

}
